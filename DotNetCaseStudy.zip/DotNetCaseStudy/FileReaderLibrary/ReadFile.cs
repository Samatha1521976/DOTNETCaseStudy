﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics.Eventing.Reader;
using System.Security.Cryptography.X509Certificates;

namespace FileReaderLibrary
{
    public class ReadFile
    {
        int networkingbreach = 0;
        int networkingnobreach = 0;
        int memorybreach = 0;
        int memorynobreach = 0;
        int hardwarebreach = 0;
        int hardwarenobreach = 0;
        FileStream fs;
        StreamWriter sw;

        
        public int GetTotalWeeks()
        {
            string FileToRead = "infralog.txt";
            string[] words;
            List<int> weeks = new List<int>();
            List<int> weeknodpulicate = new List<int>();

            using (StreamReader reader = new StreamReader(FileToRead))
            {
                string line;
                //reader object reads a single line at a time 
                //stores it in the variable string line
                while ((line = reader.ReadLine()) != null)
                {
                    words = line.Split(',');
                    Console.WriteLine(words[4]);
                    int r = Convert.ToInt32(words[4]);
                    weeks.Add(r);
                }

                weeknodpulicate = weeks.Distinct().ToList();
            }
            return weeknodpulicate.Last();

        }





        public void Weekwisedata(int week)
        {
            string FileToRead = "infralog.txt";
            string[] words;
            string result = "";
            using (StreamReader reader = new StreamReader(FileToRead))
            {
                string line;
                //reader object reads a single line at a time 
                //stores it in the variable string line
                while ((line = reader.ReadLine()) != null)
                {
                    
                    words = line.Split(',');
                    if (Convert.ToInt32(words[4]) != week)
                    {
                        break;
                    }
                    else
                    {

                        if (words[1].Equals("Network"))
                        {
                            result = networkweekwise(week, words[1], Convert.ToInt32(words[2]));
                        }
                        if (words[1].Equals("Memory"))
                        {
                            result = result + memoryweekwise(week, words[1], Convert.ToInt32(words[2]));

                        }
                        if (words[1].Equals("Hardware"))
                        {

                            result = result + hardwareweekwise(week, words[1], Convert.ToInt32(words[2]));

                        }
                    }
                 
                    


                }

            
            }
            FileStream fs = new FileStream("logreport.txt", FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.Write(result);
            sw.Flush();
            sw.Close();
            fs.Close();



        }

        public string networkweekwise(int week,string infra,int logvalue)
        {
            if (Convert.ToInt32(logvalue) > 100)
            {
                networkingbreach++;
            }
            else
            {
                networkingnobreach++;
            }
            string line = $"\n Week {week} {infra} total netwrok breach {networkingbreach}";
            line = line + $"\n Week {week} {infra} total network no breach {networkingnobreach}";
            return line;
            
        }
        public string memoryweekwise(int week, string infra, int logvalue)
        {
            if (Convert.ToInt32(logvalue) > 100)
            {
                memorybreach++;
            }
            else
            {
               memorynobreach++;
            }
            string line = $"\n Week {week} {infra} total memory breach {memorybreach}";
            line = line + $"\n Week {week} {infra} total memory no breach {memorynobreach}";
            return line;
            
        }
        public string hardwareweekwise(int week, string infra, int logvalue)
        {
            if (Convert.ToInt32(logvalue) > 100)
            {
              hardwarebreach++; 
            }
            else
            {
               hardwarenobreach++;
            }
            string line = $"\n Week {week} {infra} total hardware breach {hardwarebreach}";
            line = line + $"\n Week {week} {infra} total hardware no breach {hardwarenobreach}";

            return line;
            
        }
    }
}
